$(document).ready(function(){
	
	$.ajax({
		
		url: "/getList",
		type: "get",
		dataType: "json",
		success: function(data){
			
			var tr=[];

			for(var i=0; i<data.length; i++)
			{
				
				tr.push("<tr><td th:value='"+data[i].empId+"'>"+data[i].empId+"</td>" +
						"<td th:value='"+data[i].empName+"'>"+data[i].empName+"</td>" +
						"<td th:value='"+data[i].empAddress+"'>"+data[i].empAddress+"</td>" +
						"<td th:value='"+data[i].empEmail+"'>"+data[i].empEmail+"</td>" +
						"<td th:value='"+data[i].empPhone+"'>"+data[i].empPhone+"</td>" +
						"<td th:value='"+data[i].empDoj+"'>"+data[i].empDoj+"</td>" +
						"</tr>"	);
			}
			$('table[id=listData]').append($(tr.join('')));
			
		},
		
		error: function(data){
			alert("Please Refresh the Page");
		}
		
	});
	
});

function logout(){
$.ajax({
		
		url: "/getList"
});
}
