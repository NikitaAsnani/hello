package com.cg.repository;

import org.springframework.data.repository.CrudRepository;

import com.cg.model.EmployeeDetail;

public interface EmployeeRepository extends CrudRepository<EmployeeDetail, Long> {

}
