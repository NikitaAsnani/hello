package com.cg;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.data.MongoItemWriter;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.cg.model.EmployeeDetail;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Autowired
	public MongoTemplate mongoTemplate;
	
	@Autowired
	public DataSource dataSource;

	@Bean
	public DataSource dataSource(){
		final DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("com.mysql.jdbc.Driver");
		dataSource.setUrl("jdbc:mysql://localhost:3306/batchjob?useSSL=false");
		dataSource.setUsername("root");
		dataSource.setPassword("root");
		return dataSource;
	}
	
	@Bean
	public JdbcCursorItemReader<EmployeeDetail> reader(){
		JdbcCursorItemReader<EmployeeDetail> reader = new JdbcCursorItemReader<EmployeeDetail>();
		reader.setDataSource(dataSource());
		reader.setSql("select emp_id, emp_name, emp_address, emp_email, emp_doj, emp_phone from employee_detail");
		reader.setRowMapper(new UserRowMapper());
		return reader;
	}

	public class UserRowMapper implements RowMapper<EmployeeDetail>{

		@Override
		public EmployeeDetail mapRow(ResultSet rs, int rownum) throws SQLException {
			
			EmployeeDetail user = new EmployeeDetail();
			user.setEmpId(rs.getLong("emp_id"));
			user.setEmpName(rs.getString("emp_name"));
			user.setEmpAddress(rs.getString("emp_address"));
			user.setEmpEmail(rs.getString("emp_email"));
			user.setEmpDoj(rs.getString("emp_doj"));
			user.setEmpPhone(rs.getString("emp_phone"));
			return user;
		}
	}

	public UserItemProcessor processor(){
		return new UserItemProcessor();
	}

	@Bean 
	public MongoItemWriter<EmployeeDetail> writer(){	
		MongoItemWriter<EmployeeDetail> writer = new MongoItemWriter<EmployeeDetail>();
		writer.setTemplate(mongoTemplate);
		writer.setCollection("migratedb");
		return writer;
	}
	
	@Bean
	public Step step1(){
		return stepBuilderFactory.get("step1").<EmployeeDetail, EmployeeDetail> chunk(10)
			.reader(reader())
			.processor(processor())
			.writer(writer())
			.build();
	}
	
	@Bean 
	public Job exportUserJob(){
		return jobBuilderFactory.get("exportUserJob")
				.incrementer(new RunIdIncrementer())
				.flow(step1())
				.end()
				.build();		
	}
	
}
