package com.cg.model;

public class EmployeeDetail {

	private long id;
	private String empName;
	private String empAddress;
	private String empEmail;
	private String empPhone;
	private String empDoj;
	
	public EmployeeDetail() {
	
	}

	public EmployeeDetail(long empId, String empName, String empAddress, String empEmail, String empPhone,
			String empDoj) {
		
		this.id = empId;
		this.empName = empName;
		this.empAddress = empAddress;
		this.empEmail = empEmail;
		this.empPhone = empPhone;
		this.empDoj = empDoj;
	}

	@Override
	public String toString() {
		return "EmployeeDetail [empId=" + id + ", empName=" + empName + ", empAddress=" + empAddress + ", empEmail="
				+ empEmail + ", empPhone=" + empPhone + ", empDoj=" + empDoj + "]";
	}

	public long getEmpId() {
		return id;
	}

	public void setEmpId(long empId) {
		this.id = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpAddress() {
		return empAddress;
	}

	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}

	public String getEmpEmail() {
		return empEmail;
	}

	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}

	public String getEmpPhone() {
		return empPhone;
	}

	public void setEmpPhone(String empPhone) {
		this.empPhone = empPhone;
	}

	public String getEmpDoj() {
		return empDoj;
	}

	public void setEmpDoj(String empDoj) {
		this.empDoj = empDoj;
	}
	
	
}
