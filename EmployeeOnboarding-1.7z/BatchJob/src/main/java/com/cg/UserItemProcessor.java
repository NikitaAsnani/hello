package com.cg;

import org.springframework.batch.item.ItemProcessor;

import com.cg.model.EmployeeDetail;

public class UserItemProcessor implements ItemProcessor<EmployeeDetail, EmployeeDetail> {

	@Override
	public EmployeeDetail process(EmployeeDetail emp) throws Exception{
		return emp;
	}
}
