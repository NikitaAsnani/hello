package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.cg.domain.EmployeeDetail;
import com.cg.repository.EmployeeRepository;

@RestController
public class EOController {

	@Autowired
	public EmployeeRepository employeeRepository;
	
	@Autowired
	RestTemplate restTemplate;
	
	@Bean
    RestTemplate restTemplate() {
        return new RestTemplate();
    }
	
	@RequestMapping("/")
	public ModelAndView index(){
		return new ModelAndView("index");
	}
	
	@RequestMapping("/getList")
	public List<EmployeeDetail> getlist(){
		List<EmployeeDetail> list = (List<EmployeeDetail>) employeeRepository.findAll();
		return list;
	}
	
	@RequestMapping("/addEmployee")
	public ModelAndView addEmp(){
		System.out.println("inside add employee");
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("employeeForm", new EmployeeDetail());
		modelAndView.setViewName("views/empForm");
		return modelAndView;
	}
	
	@RequestMapping("/empDetail")
	public ModelAndView getDetails(@ModelAttribute ("employeeFrom") EmployeeDetail emp, BindingResult bindingResult, ModelAndView modelAndView){
		if(bindingResult.hasErrors()){
			return modelAndView;
		}
		employeeRepository.save(emp);
		String msg= restTemplate.getForObject("http://localhost:8085", String.class);
		modelAndView.addObject("message", msg);
		modelAndView.setViewName("views/status");
		return modelAndView;
	}
}
